Connor Munro, cmunro1, B00656486
Project does not compile, simply submitting all that I've got so far
