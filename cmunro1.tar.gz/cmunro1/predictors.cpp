#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<cmath>
#include"static.h"
#include"bimodal_twobit.h"
#include"gshare.h"
#include"tournament.h"

using namespace std;

int main(int argc, char *argv[])
{
  unsigned long long addr;
  string behavior;
  //unimodal
  staticPredictor alwaysT = new staticPredictor(true);
  staticPredictor alwaysNT = new staticPredictor(false);
  //bimodal single bits
  bimodalSingBit sing16 = new bimodalSingBit(16);
  bimodalSingBit sing32 = new bimodalSingBit(32);
  bimodalSingBit sing128 = new bimodalSingBit(128);
  bimodalSingBit sing256 = new bimodalSingBit(256);
  bimodalSingBit sing512 = new bimodalSingBit(512);
  bimodalSingBit sing1024 = new bimodalSingBit(1024);
  bimodalSingBit sing2048 = new bimodalSingBit(2048);
  //bimodal two bits
  bimodalTwoBit doub16 = new bimodalTwoBit(16);
  bimodalTwoBit doub32 = new bimodalTwoBit(32);
  bimodalTwoBit doub128 = new bimodalTwoBit(128);
  bimodalTwoBit doub256 = new bimodalTwoBit(256);
  bimodalTwoBit doub512 = new bimodalTwoBit(512);
  bimodalTwoBit doub1024 = new bimodalTwoBit(1024);
  bimodalTwoBit doub2048 = new bimodalTwoBit(2048);
  //global history register
  gshare gsh3 = new gshare(3);
  gshare gsh4 = new gshare(4);
  gshare gsh5 = new gshare(5);
  gshare gsh6 = new gshare(6);
  gshare gsh7 = new gshare(7);
  gshare gsh8 = new gshare(8);
  gshare gsh9 = new gshare(9);
  gshare gsh10 = new gshare(10);
  gshare gsh11 = new gshare(11);
  //tournament
  tournament tourney = new tournament();
  //variables to hold correct amounts
  int alwaysTakenCorr = 0;
  int alwaysNTCorr = 0;
  int bimSing16 = 0, bimSing32 = 0, bimSing128 = 0, bimSing256 = 0, bimSing512 = 0, bimSing1024 = 0, bimSing2048 = 0;
  int bTwo16 = 0, bTwo32 = 0, bTwo128 = 0, bTwo256 = 0, bTwo512 = 0, bTwo1024 = 0, bTwo2048 = 0;
  int gshare3 = 0, gshare4 = 0, gshare5 = 0, gshare6 = 0, gshare7 = 0, gshare8 = 0, gshare9 = 0, gshare10 = 0, gshare11 = 0;
  int tournamentCorr = 0;
  int total = 0;
  ifstream file(argv[1]);
  ofstream ofile(argv[2]);
  while(file >> std::hex >> addr >> behavior)
  {
    alwaysT.predict(behavior);
    alwaysNT.predict(behavior);
    sing16.predict(addr, behavior);
    sing32.predict(addr, behavior);
    sing128.predict(addr, behavior);
    sing256.predict(addr, behavior);
    sing512.predict(addr, behavior);
    sing1024.predict(addr, behavior);
    sing2048.predict(addr, behavior);
    doub16.predict(addr, behavior);
    doub32.predict(addr, behavior);
    doub128.predict(addr, behavior);
    doub256.predict(addr, behavior);
    doub512.predict(addr, behavior);
    doub1024.predict(addr, behavior);
    doub2048.predict(addr, behavior);
    gsh3.predict(addr, behavior);
    gsh4.predict(addr, behavior);
    gsh5.predict(addr, behavior);
    gsh6.predict(addr, behavior);
    gsh7.predict(addr, behavior);
    gsh8.predict(addr, behavior);
    gsh9.predict(addr, behavior);
    gsh10.predict(addr, behavior);
    gsh11.predict(addr, behavior);
    tourney.predict(addr, behavior);
  }
  alwaysTakenCorr = alwaysT.getCorr();
  alwaysNTCorr = alwaysNT.getCorr();
  bimSing16 = sing16.getCorr();
  bimSing32 = sing32.getCorr();
  bimSing128 = sing128.getCorr();
  bimSing256 = sing256.getCorr();
  bimSing512 = sing512.getCorr();
  bimSing1024 = sing1024.getCorr();
  bimSing2048 = sing2048.getCorr();
  bTwo16 = doub16.getCorr();
  bTwo32 = doub32.getCorr();
  bTwo128 = doub128.getCorr();
  bTwo256 = doub256.getCorr();
  bTwo512 = doub512.getCorr();
  bTwo1024 = doub1024.getCorr();
  bTwo2048 = doub2048.getCorr();
  gshare3 = gsh3.getCorr();
  gshare4 = gsh4.getCorr();
  gshare5 = gsh5.getCorr();
  gshare6 = gsh6.getCorr();
  gshare7 = gsh7.getCorr();
  gshare8 = gsh8.getCorr();
  gshare9 = gsh9.getCorr();
  gshare10 = gsh10.getCorr();
  gshare11 = gsh11.getCorr();
  tournamentCorr = tourney.getCorr();
  total = alwaysT.getTot();
  if(ofile.is_open())
  {
    ofile << alwaysTakenCorr << "," << total << ";\n";
    ofile << alwaysNTCorr << "," << total << ";\n";
    ofile << bimSing16 << "," << total << "; " << bimSing32 << "," << total << "; " << bimSing128 << "," << total << "; " << bimSing256 << "," << total << "; " << bimSing512 << "," << total << "; " << bimSing1024 << "," << total << "; " << bimSing2048 << "," << total << ";\n";
    ofile << doub16 << "," << total << "; " << doub32 << "," << total << "; " << doub128 << "," << total << "; " << doub256 << "," << total << "; " << doub512 << "," << total << "; " << doub1024 << "," << total << "; " << doub2048 << "," << total << ";\n";
    ofile << gshare3 << "," << total << "; " << gshare4 << "," << total << "; " << gshare5 << "," << total << "; " << gshare6 << "," << total << "; " << gshare7 << "," << total << "; " << gshare8 << "," << total << "; " << gshare9 << "," << total << "; " << gshare10 << "," << total << "; " << gshare11 << "," << total << ";\n";
    ofile << tournamentCorr << "," << total << ";";
    ofile.close();
  }
  else
  {
    cout << "Unable to open output file";
  }
  return 0;
}
