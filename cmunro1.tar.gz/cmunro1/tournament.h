#ifndef tournament
#define tournament

#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<cmath>
#include"bimodal_twobit.h"
#include"gshare.h"

class tournament
{
  private:
    bimodalTwoBit bimodal;
    gshare gshare;
    unsigned short selector[2048];
    unsigned int correct;
    unsigned int total;
  public:
    tournament tournament();
    void changeCell(int, bool, bool);
    void predict(unsigned long long, bool);
    void setCell(int i, unsigned short j) {this->selector[i] = j;};
    void incCorr() {this.correct++;};
    void incTot() {this.total++};
    void incCell(int i) {this.selector[i]++;};
    void decCell(int i) {this.selector[i]--;};
    bool bimodalPredict(unsigned long long addr, bool result)
    {
      return this.bimodal.predict(addr, result);
    };
    bool gsharePredict(unsigned long long addr, bool result)
    {
      return this.gshare.predict(addr, result);
    };
    unsigned short getCell(int i) {return this.selector[i];};
};

#endif
