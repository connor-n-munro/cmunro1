#ifndef BIMODAL_SINGBIT
#define BIMODAL_SINGBIT

#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<cmath>

class bimodalSingBit
{
    private:
      unsigned int size;
      unsigned int histTable[];
      unsigned int total;
      unsigned int correct;

    public:
      bimodalSingBit bimodalSingBit(unsigned int size)
      {
        this->size = size;
        this->total = 0;
        this->correct = 0;
	this->histTable = new histTable[size];
        for(unsigned int i = 0; i < size; i++)
        {
          histTable[i] = 0;
        }
      };
      void predict(unsigned long long, bool);
      void changeCell(unsigned int);
      unsigned int getI(unsigned int i){return this->histTable[i];};
      unsigned int getSize() {return this->size;};
      void incCorr() {this->correct++;};
      void incTot() {this->total++};
      unsigned int getCorr() {return this->correct;};
      unsigned int getTot() {return this->total;};
};

#endif
