#ifndef GSHARE
#define GSHARE

#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<cmath>

class gshare
{
  private:
      unsigned short histTable[2048];
      unsigned short GHR;
      unsigned short n;
      unsigned int total;
      unsigned int correct;
  public:
    gshare gshare(unsigned int bits)
    {
      this->n = bits;
      this->GHR = 0;
      this->total = 0;
      this->correct = 0;
      for(unsigned int i = 0; i < 2048; i++)
      {
        histTable[i] = 0;
      }
    }
    bool predict(unsigned long long, bool);
    void updateGHR(bool);
    unsigned short getGHR() {return this.GHR;};
    void incCorr() {this.correct++;};
    void incTot() {this.total++;};
    unsigned int getCorr() {return this.correct;};
    unsigned int getTot() {return this.total;};
    void updateGHR(bool result)
    {
      this.GHR = GHR << 1;
      if(result)
      {
        this.GHR++;
      }
    }
    unsigned short getN() {return this.n;};
    unsigned short getI(unsigned int i) {return this.histTable[i];};
    void changeCell(unsigned int, bool);
    void incCell(int i) {histTable[i]++;};
    void decCell(int i) {histTable[i]--;};

};

#endif
