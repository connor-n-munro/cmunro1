#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<cmath>
#include"bimodal_twobit.h"

using namespace std;
void bimodalTwoBit::changeCell(unsigned int i, bool right)
{
  if(getI(i) == 0)
  {
    if(!right)
    {
      incCell(i);
    }
  }
  else if(getI(i) == 1)
  {
    if(right)
    {
      decCell(i);
    }
    else
    {
      incCell(i);
    }
  }
  else if(getI(i) == 2)
  {
    if(right)
    {
      incCell(i);
    }
    else
    {
      decCell(i);
    }
  }
  else
  {
    if(right)
    {
      decCell(i);
    }
  }
}
bool predict(unsigned long long addr, bool result)
{
  bool accuracy = false;
  //get bits to AND with PC
   unsigned int n = pow(2, getSize()+1) - 1;
   unsigned short progCounter = addr & n;
   if(getI(progCounter) == 0 || getI(progCounter) == 1)
   {
     if(!result)
     {
       incCorr();
       changeCell(progCounter, true);
       accuracy = true;
     }
     else
     {
       changeCell(progCounter, false);
     }
     incTot();
   }
   else if(getI(progCounter) == 2 || getI(progCounter) == 3)
   {
     if(result)
     {
       incCorr();
       changeCell(progCounter, true);
       accuracy = true;
     }
     else
     {
       changeCell(progCounter, false);
     }
     incTot();
   }
   return accuracy;
}
