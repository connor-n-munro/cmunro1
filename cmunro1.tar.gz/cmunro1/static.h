#ifndef STATIC_H
#define STATIC_H

#include<iostream>
#include<fstream>
#include<sstream>
#include<string>

class staticPredictor
{
  private:
    bool prediction;
    int correct;
    int total;
  public:
    staticPredictor staticPredictor(bool);
    void predict(bool);
    void setPred(bool pred) {this->prediction = pred;};
    bool getPred() {return this.prediction;};
    void incTot() {this.total++;};
    void incCorr() {this.correct++;};
    unsigned int getCorr() {return this.correct;};
    unsigned int getTot() {return this.total;};
};

#endif
