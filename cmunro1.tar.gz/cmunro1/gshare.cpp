#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<cmath>
#include"gshare.h"

void ghsare::changeCell(unsigned int i, bool right)
{
  if(getI(i) == 0)
  {
    if(!right)
    {
      incCell(i);
    }
  }
  else if(getI(i) == 1)
  {
    if(right)
    {
      decCell(i);
    }
    else
    {
      incCell(i);
    }
  }
  else if(getI(i) == 2)
  {
    if(right)
    {
      incCell(i);
    }
    else
    {
      decCell(i);
    }
  }
  else
  {
    if(right)
    {
      decCell(i);
    }
  }
}
void gshare::predict(unsigned long long addr, bool result)
{
  bool accuracy = false;
  unsigned int n = pow(2, getSize()+1) - 1;
  unsigned short progCounter = addr & n;
  unsigned short r =  (pow(2, getN()+1) - 1) & getGHR();
  unsigned short pcxor = progCounter^r;
  updateGHR(result);
  if(getI(pcxor) == 0 || getI(pcxor) == 1)
  {
    if(!result)
    {
      incCorr();
      changeCell(pcxor, true);
      accuracy = true;
    }
    else
    {
      changeCell(pcxor, false);
    }
    incTot();
  }
  else
  {
    if(result)
    {
      incCorr();
      changeCell(pcxor, true);
      accuracy = true;
    }
    else
    {
      changeCell(pcxor, false);
    }
    incTot();
  }
  return accuracy;
}
