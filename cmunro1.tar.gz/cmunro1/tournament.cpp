#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<cmath>
#include"bimodal_twobit.h"
#include"gshare.h"
#include"tournament.h"

tournament tournament::tournament()
{
  this->correct = 0;
  this->total = 0;
  for(int i = 0; i < 2048; i++)
  {
    setCell(i, 2);
  }
  this->bimodal = new bimodalTwoBit(2048);
  this->gshare = new gshare(11);
}
void tournament::changeCell(int i, bool bimodal, bool gshare)
{
  if(bimodal != gshare)
  {
    if(bimodal && !gshare)
    {
      incCell(i);
    }
    else
    {
      decCell(i);
    }
  }
}
void tournament::predict(unsigned long long addr, bool result)
{
  unsigned int n = pow(2, getSize()+1) - 1;
  unsigned short progCounter = addr & n;
  bool bimodal = bimodalPredict(addr, result);
  bool gshare = gsharePredict(addr, result);
  if(getCell(progCounter) == 0 || getCell(progCounter) == 1)
  {
    if(gshare)
    {
      incCorr();
    }
    changeCell(progCounter, bimodal, gshare);
    incTot();
  }
  else if(getCell(progCounter) == 2 || getCell(progCounter) == 3)
  {
    if(bimodal)
    {
      incCorr();
    }
    changeCell(progCounter, bimodal, gshare);
    incTot();
  }
}
