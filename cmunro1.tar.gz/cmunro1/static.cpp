#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include"static.h"

staticPredictor staticPredictor::staticPredictor(bool pred)
{
  this->correct = 0;
  this->total = 0;
  this->prediction = pred;
}
void predict(bool result)
{
  if(result == getPred())
  {
    incCorr();
  }
  incTot();
}
