#ifndef BIMODAL_TWOBIT
#define BIMODAL_TWOBIT

#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<cmath>

class bimodalTwoBit
{
  private:
    unsigned int size;
    unsigned int histTable[];
    unsigned int total;
    unsigned int correct;
  public:
      bimodalTwoBit bimodalTwoBit(unsigned int size)
    {
      this->size = size;
      this->total = 0;
      this->correct = 0;
	this->histTable = new histTable[size];
      for(unsigned int i = 0; i < this.size; i++)
      {
        this.histTable[i] = 0;
      }
    };
    void changeCell(unsigned int, bool);
    bool predict(unsigned long long, bool);
    void incCorr() {this->correct++;};
    void incTot() {this->total++};
    unsigned int getCorr() {return this->correct;};
    unsigned int getTot() {return this->total;};
};

#endif
