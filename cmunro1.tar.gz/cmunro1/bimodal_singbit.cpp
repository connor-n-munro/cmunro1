#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<cmath>
#include"bimodal_singbit.h"

using namespace std;

void bimodalSingBit::predict(unsigned long long addr, bool behavior)
{
  //get bits to AND with PC
   unsigned int n = pow(2, getSize()+1) - 1;
   unsigned short progCounter = addr & n;
   if(getI(progCounter) == 0)
   {
     if(!behavior)
     {
       incCorr();
     }
     else
     {
       changeCell(progCounter);
     }
     incTot();
   }
   else
   {
     if(behavior)
     {
       incCorr();
     }
     else
     {
       changeCell(progCounter);
     }
     incTot();
   }
}
void bimodalSingBit::changeCell(unsigned int i)
{
  if(histTable[i] == 0)
  {
    histTable[i]++;
  }
  else
  {
    histTable[i]--;
  }
}
